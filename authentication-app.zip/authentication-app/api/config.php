<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'my_password');
define('DB_HOST', 'localhost');
define('DB_NAME', 'pavandatabase');

?>
